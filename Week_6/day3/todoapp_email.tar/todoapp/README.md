# Install

```
rake db:setup
```
