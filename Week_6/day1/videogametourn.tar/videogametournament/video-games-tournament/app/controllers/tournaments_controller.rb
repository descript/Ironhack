class TournamentsController < ApplicationController
  def index
    render(:index)
  end

  def show
    tournaments = Tournament.all.limit(50)
    render json: tournaments
  end

  def create
    tournament = Tournament.new(tournament_params)
    if tournament.save
      render json: tournament, status: :created
    else
      render json: {error: tournament.error.full_messages}, status: 404
    end
  end

  private

  def tournament_params
    params.require(:tournament).permit(:name)
  end
end
