class PlayersController < ApplicationController
end
