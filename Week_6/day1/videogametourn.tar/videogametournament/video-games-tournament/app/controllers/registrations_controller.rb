class RegistrationsController < ApplicationController
end
