# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
Player.create(name: "Jason")
Player.create(name: "Xian")
Player.create(name: "Karayana")
Player.create(name: "Shirlee")
Tournament.create(name: "Design Deathmatch")
Tournament.create(name: "Code for kidz")
